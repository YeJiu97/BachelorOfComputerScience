 #include "SeaCreature.h"

using namespace std;

string SeaCreature::toString()
 {
      return "A sea creature";
 }
