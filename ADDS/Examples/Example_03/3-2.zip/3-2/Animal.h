#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>

class Animal {
    public: 
        virtual std::string toString();
};

#endif
