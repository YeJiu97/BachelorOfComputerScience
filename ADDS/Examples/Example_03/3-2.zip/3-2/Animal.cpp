#include "Animal.h"

using namespace std;

string Animal::toString() {
    return "An animal";
}
