 #include "Bird.h"

using namespace std;

string Bird::toString() {
     return "A bird";
 }
