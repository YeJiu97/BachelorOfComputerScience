#include "Animal.h"
#include <string>

class SeaCreature :public Animal {
    public:
        virtual std::string toString();
};
