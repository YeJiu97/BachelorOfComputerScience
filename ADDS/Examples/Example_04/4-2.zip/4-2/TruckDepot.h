#include<vector>
class TruckDepot {
public:
   void init_mem(int pileSize, int truckCapacity);
    int numTrucks(int pileSize, int truckCapacity);
    int numTrucks_mem(int pileSize, int truckCapacity, int** mem);
    
};



